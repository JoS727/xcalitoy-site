MAVERICK PAINT MASK ARTWORK — SHOP REVIEW SET
All SVGs are true vector closed paths; no embedded images, fonts or live strokes.
Sizes are PROVISIONAL, not measured on the vehicle. Import using stated mm units,
verify physical size and test a paper placement before cutting. Keep proportions.

01 Calitoy brush: 30 inches wide, simplified trace of supplied gold logo.
02 Love Louder: 16 inches wide, simplified trace of supplied round badge.
03 TAROSYN: 30 inches wide, reconstructed serif lettering, NOT exact original logo.
04 Ocean Beach: 24 inches wide. 05 CALQ: 8 inches wide.
06 Lotus: NEW simplified motif, 12-inch-wide artboard; not a trace of mockup flowers.
07 Crosshatch: 24 x 8 inches, 3.2 mm line width, united crossings.

BLACK VECTOR AREAS REPRESENT THE DESIGN, NOT THE PAINT COLOR.
To preserve existing Mermaid lettering: weed away background vinyl; retain black
design shapes as positive masks. Transfer all letters and detached parts with
application tape. Paint surrounding areas black, then remove masks according to
the coating and mask manufacturers' instructions.
To spray gold crosshatch or other gold designs: weed OUT the black design shapes;
retain surrounding vinyl and internal islands as a negative stencil. Transfer tape
is needed to position islands. Add a surrounding mask border in cutter software.
These are adhesive vinyl masks, NOT reusable loose stencils; bridges are not added.

Shop: select paint-mask film compatible with the coating; confirm paint is ready
for adhesive masking. Dry-to-touch does not establish masking readiness. Test
adhesion/removal on an inconspicuous area first. Follow paint/film labels.
Cut normal reading orientation, NOT mirrored, for external vehicle application.
Fine brush tips remain; review minimum feature width at FINAL size and test cut.
Do not auto-outline filled SVGs a second time; existing contours are cut boundaries.
Do not cut the preview PNG. No registration marks or vehicle contour templates.
Use the supplied art as separate decals/masks, not as a measured vehicle wrap.
